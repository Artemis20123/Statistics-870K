## The Short-term Impacts of COVID-19 Lockdown on Urban Air Pollution in China

*Guojun He, Yuhang Pan, and Takanao Tanaka*

**

Data for Paper "The Short-term Impacts of COVID-19 Lockdown on Urban Air Pollution in China "

**Data:** 

(1) wf.dta: merged workfile data (city-by-day level) in this project.

(2) city_yb.dta: city's year book in 2017.

Link to the Paper at *Nature Sustainability*: https://www.nature.com/articles/s41893-020-0581-y

For replication issues, please feel free to contact us at yhyhpan [at] gmail.com.

