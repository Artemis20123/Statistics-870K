## The Short-term Impacts of COVID-19 Lockdown on Urban Air Pollution in China

*Guojun He, Yuhang Pan, and Takanao Tanaka*

Codes for Paper "The Short-term Impacts of COVID-19 Lockdown on Urban Air Pollution in China "

**Code List:** 

(1) master.do : codes to produce the results.

Link to the Paper at *Nature Sustainability*: https://www.nature.com/articles/s41893-020-0581-y

For replication issues, please feel free to contact us at yhyhpan [at] gmail.com.

